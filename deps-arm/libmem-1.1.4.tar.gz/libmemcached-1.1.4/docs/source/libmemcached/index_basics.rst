Basics
======

.. toctree::
    :titlesonly:

    memcached_create
    memcached_get
    memcached_set
    memcached_delete
    memcached_quit
